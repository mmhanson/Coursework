﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Program
    {
        /// <summary>
        /// This is the main function
        /// </summary>
        /// <param name="args">this is a changed line</param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello wooorld!");

            Console.WriteLine("this is a new line");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TipCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void billBox_TextChanged(object sender, EventArgs e)
        {
            if (billBox.Text != "")
            {
                double tip, bill;
                if (Double.TryParse(billBox.Text, out bill))
                {
                    tip = bill * 0.2;
                    outputBox.Text = tip.ToString();
                    totalBox.Text = (bill + tip).ToString();
                }
                else
                {
                    MessageBox.Show("You need to input a number");
                }
            }

            else
            {
                MessageBox.Show("You need an input.");
            }
        }
    }
}
